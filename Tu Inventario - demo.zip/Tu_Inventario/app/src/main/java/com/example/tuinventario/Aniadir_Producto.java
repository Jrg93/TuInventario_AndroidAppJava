package com.example.tuinventario;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Aniadir_Producto extends AppCompatActivity {

    TextView txt_nombre, txt_precio, txt_proveedor, txt_marca, txt_cantidad, txt_tipo;
    EditText edtxt_nombre, edtxt_precio, edtxt_proveedor, edtxt_marca, edtxt_cantidad, edtxt_tipo;
    Button btn_añadir, btn_volver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aniadir__producto);

        txt_nombre = findViewById(R.id.txt_nombrepro);
        txt_precio = findViewById(R.id.txt_preciopro);
        txt_proveedor = findViewById(R.id.txt_proveedorpro);
        txt_marca = findViewById(R.id.txt_marcapro);
        txt_cantidad = findViewById(R.id.txt_cantidadpro);
        txt_tipo = findViewById(R.id.txt_tipopro);

        edtxt_nombre = findViewById(R.id.edtxt_nombrepro);
        edtxt_precio = findViewById(R.id.edtxt_preciopro);
        edtxt_proveedor = findViewById(R.id.edtxt_proveedorpro);
        edtxt_marca = findViewById(R.id.edtxt_marcapro);
        edtxt_cantidad = findViewById(R.id.edtxt_cantidadpro);
        edtxt_tipo = findViewById(R.id.edtxt_tipopro);

        btn_añadir = findViewById(R.id.btn_añadirpro);
        btn_volver = findViewById(R.id.btn_volverpro);

        btn_añadir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogoAñadir();
            }
        });

        btn_volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent volver = new Intent(Aniadir_Producto.this, Menu.class);
                startActivity(volver);
            }
        });

    }

    private void dialogoAñadir(){
        AlertDialog.Builder builder = new AlertDialog.Builder(Aniadir_Producto.this);
        builder.setTitle("Mensaje")
                .setMessage("Producto Añadido con éxito")
                .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).show();
    }












}
