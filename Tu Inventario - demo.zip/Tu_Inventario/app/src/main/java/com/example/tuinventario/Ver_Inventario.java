package com.example.tuinventario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TableLayout;

import java.util.ArrayList;

public class Ver_Inventario extends AppCompatActivity {

    private TableLayout tableLayout;
    private Button btn_volver;
    /*private String[]header={"Nombre", "Stock", "Precio", "Proveedor", "Marca"};
    private ArrayList<String[]> rows = new ArrayList<>();*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver__inventario);

        tableLayout = (TableLayout) findViewById(R.id.table);
        btn_volver = (Button) findViewById(R.id.btn_volverInv);

        btn_volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent volver = new Intent(Ver_Inventario.this, Menu.class);
                startActivity(volver);
            }
        });

        /*TableDynamic tableDynamic = new TableDynamic(tableLayout, getApplicationContext());
        tableDynamic.addHeader(header);
        tableDynamic.addData(getProductos());*/


    }

    /*private ArrayList<String[]> getProductos(){
        rows.add(new String[]{"Serv.220u", "10", "1090", "CMPC", "Nova"});
        rows.add(new String[]{"P.I.18u50m", "6", "9950", "CMPC", "Elite"});
        return rows;
    }*/

}