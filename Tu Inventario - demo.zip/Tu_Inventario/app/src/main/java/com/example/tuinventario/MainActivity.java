package com.example.tuinventario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView txt_titulo, txt_sesion, txt_email, txt_pass;
    EditText edtxt_email, edtxt_pass;
    Button btn_entrar, btn_registrarse, btn_repass;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txt_titulo = findViewById(R.id.txt_titulo);
        txt_sesion = findViewById(R.id.txt_sesion);
        txt_email = findViewById(R.id.txt_email);
        txt_pass = findViewById(R.id.txt_pass);
        edtxt_email = findViewById(R.id.edtxt_email);
        edtxt_pass = findViewById(R.id.edtxt_pass);
        btn_entrar = findViewById(R.id.btn_entrar);
        btn_registrarse = findViewById(R.id.btn_registrarse);
        btn_repass = findViewById(R.id.btn_recuperpass);


        btn_registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent btn_regis = new Intent(MainActivity.this, Registrarse.class);
                startActivity(btn_regis);
            }
        });

        btn_entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent btn_entrar = new Intent(MainActivity.this, Menu.class);
                startActivity(btn_entrar);
            }
        });



















    }
}