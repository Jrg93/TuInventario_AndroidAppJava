package com.example.tuinventario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu extends AppCompatActivity {

    Button btn_añadir, btn_perfil, btn_stock, btn_inventario, btn_tutorial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        btn_añadir = findViewById(R.id.btn_añadirMenu);
        btn_perfil = findViewById(R.id.btn_perfilMenu);
        btn_stock = findViewById(R.id.btn_stockMenu);
        btn_inventario = findViewById(R.id.btn_inventarioMenu);
        btn_tutorial = findViewById(R.id.btn_tutorial);

        btn_añadir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent añadir = new Intent(Menu.this, Aniadir_Producto.class);
                startActivity(añadir);
            }
        });
        btn_stock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent stock = new Intent(Menu.this, Act_Stock.class);
                startActivity(stock);
            }
        });

        btn_perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent perfil = new Intent(Menu.this, Perfil.class);
                startActivity(perfil);
            }
        });

        btn_inventario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent inventario = new Intent(Menu.this, Ver_Inventario.class);
                startActivity(inventario);
            }
        });
    }
}